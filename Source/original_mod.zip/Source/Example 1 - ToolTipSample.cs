﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkMatterGenerator
{
    /// <summary>
    /// ToolTip-Test 1: This is a test for the tooltip-info. Add 'ToolTipSample.Sample' and look at the tooltip
    /// </summary>
    class ToolTipSample
    {

        /// <summary>
        /// ToolTip-Test 2: Do you see this text in your quick-info, when you add it?
        /// This way you can make short descriptions of your function.
        /// </summary>
        public static void Sample()
        {
            //...
            return;
        }

    }
}
